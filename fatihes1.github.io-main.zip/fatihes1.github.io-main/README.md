# fatihes1.github.io
Personal Resume Website
<h4>
Released as the first version. It will be updated from time to time. <a href ="https://fatihes1.github.io/" target="_blank" >Click </a>here to view.
</h4>
